"""
model.py – load the persisted vectoriser + classifier and expose
           a single predict_sentiment(text) → {label, confidence}.

CRITICAL: the text must go through the EXACT same cleaning + stemming
          that train_model.py applied before vectorisation.  That
          pipeline is duplicated here so the app has zero extra deps.
"""

import os, re, pickle
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

# ─── paths ─────────────────────────────────────────────────────
BASE_DIR  = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR = os.path.join(BASE_DIR, "model")

with open(os.path.join(MODEL_DIR, "vectorizer.pkl"), "rb") as f:
    vectorizer = pickle.load(f)
with open(os.path.join(MODEL_DIR, "classifier.pkl"), "rb") as f:
    classifier = pickle.load(f)

# ─── cleaning pipeline (must match train_model.py exactly) ─────
EXTRA_STOP = {"read", "more", "flipkart", "certified", "buyer", "product"}
ALL_STOP   = ENGLISH_STOP_WORDS.union(EXTRA_STOP)

_SUFFIXES = ["ingly","tion","sion","ment","ness","able","ible",
             "ous","ive","ful","less","ing","ed","ly","er","es","s"]

def _stem(word: str) -> str:
    for s in _SUFFIXES:
        if word.endswith(s) and len(word) - len(s) >= 3:
            return word[: -len(s)]
    return word

def _clean(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = text.replace("READ MORE", "")
    text = re.sub(r'[^\w\s]', ' ', text)
    text = re.sub(r'\d+',    ' ', text)
    text = re.sub(r'\s+',    ' ', text).strip().lower()
    tokens = [_stem(t) for t in text.split()
              if t not in ALL_STOP and len(t) > 2]
    return " ".join(tokens)


# ─── public API ────────────────────────────────────────────────
def predict_sentiment(text: str) -> dict:
    """
    Returns
    -------
    dict  { "label": "Positive"|"Negative",
            "confidence": float  (0–100, 1 dp) }
    """
    cleaned = _clean(text)
    if not cleaned:
        # edge case: entire input was stopwords / punctuation
        return {"label": "Neutral", "confidence": 0.0}

    vec = vectorizer.transform([cleaned])

    pred = classifier.predict(vec)[0]                      # 0 or 1
    label = "Positive" if pred == 1 else "Negative"

    # confidence: use predict_proba if available (LogReg, NB, RF, GB)
    # fall back to decision_function magnitude for LinearSVC
    if hasattr(classifier, "predict_proba"):
        confidence = round(float(max(classifier.predict_proba(vec)[0])) * 100, 1)
    elif hasattr(classifier, "decision_function"):
        raw = float(classifier.decision_function(vec)[0])
        # map raw score to a rough 50-100 % confidence band
        confidence = round(min(50 + abs(raw) * 25, 99.9), 1)
    else:
        confidence = 0.0

    return {"label": label, "confidence": confidence}