"""
main.py – Flask application entry-point
=========================================
Two input modes
  1. Paste a Flipkart product-page URL  →  scrape & analyse every review.
  2. Type / paste review text manually  →  instant single-review prediction.

Routes
  GET  /          – render the UI
  POST /          – handle either mode (form submit)
  POST /api/predict – lightweight JSON endpoint for single-review prediction
"""

import sys, os, re
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, render_template, request, jsonify
from scraper import get_reviews
from model  import predict_sentiment
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

app = Flask(__name__)

# ── stopwords shared by the pain-point extractor ──────────────
_EXTRA_STOP = {
    "read","more","flipkart","certified","buyer","product","like","get",
    "one","also","much","really","buy","good","even","know","think","say",
    "want","use","new","time","people","way","make","look","thing","take",
    "come","see","seem","give","find","tell","ask","work","call","try",
    "need","become","leave","put","mean","keep","let","begin","show",
    "hear","play","run","move","live","believe","hold","bring","happen",
    "write","provide","sit","stand","lose","pay","meet","include",
    "continue","set","learn","change","lead","understand","watch",
    "follow","stop","speak","allow","add","spend","grow","open","walk",
    "win","teach","offer","remember","love","consider","appear","wait",
    "serve","die","send","expect","build","stay","fall","cut","reach",
    "kill","remain","got","dont","didn","wasn","didnt","wasnt","actually",
    "really","already","still","just","also","back","now","first","last",
    "every","another","around","many","much","well","still","even","never",
    "always","ever","quite","rather","really","very","too","enough",
}
_ALL_STOP = ENGLISH_STOP_WORDS.union(_EXTRA_STOP)


def _extract_pain_points(results: list[dict], top_n: int = 8) -> list[dict]:
    """
    From the subset of results labelled Negative, tokenise the comment
    text, drop stopwords, count, and return the top-n keywords with counts.
    Returns []  when there are no negative reviews.
    """
    neg_texts = [r["comment"] for r in results if r["sentiment"] == "Negative"]
    if not neg_texts:
        return []

    word_counts: Counter = Counter()
    for text in neg_texts:
        text = text.replace("READ MORE", "")
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\d+', ' ', text)
        tokens = [w.lower() for w in text.split()
                  if w.lower() not in _ALL_STOP and len(w) > 2]
        word_counts.update(tokens)

    return [{"word": w, "count": c} for w, c in word_counts.most_common(top_n)]


# ---------------------------------------------------------------------------
# Main page
# ---------------------------------------------------------------------------
@app.route("/", methods=["GET", "POST"])
def home():
    results      = []
    error        = None          # user-facing error message
    input_url    = ""
    input_text   = ""
    summary      = {}            # { total, positive, negative, pos_pct }

    if request.method == "POST":
        mode       = request.form.get("mode", "url")          # "url" | "text"
        input_url  = request.form.get("url", "").strip()
        input_text = request.form.get("review_text", "").strip()

        if mode == "url":
            # ── URL / scrape mode ──
            if not input_url:
                error = "Please paste a valid Flipkart product URL."
            else:
                reviews = get_reviews(input_url)
                if not reviews:
                    error = (
                        "Could not scrape reviews from the URL. "
                        "Flipkart may have blocked the request or the page "
                        "layout has changed. Try the Manual Text mode instead."
                    )
                else:
                    for r in reviews:
                        sentiment = predict_sentiment(r["comment"])
                        results.append({
                            "comment":    r["comment"],
                            "rating":     r["rating"],
                            "sentiment":  sentiment["label"],
                            "confidence": sentiment["confidence"],
                        })
        else:
            # ── Manual text mode ──
            if not input_text:
                error = "Please type or paste at least one review."
            else:
                # split on double-newline so users can paste several reviews
                chunks = [c.strip() for c in input_text.split("\n") if c.strip()]
                for chunk in chunks:
                    sentiment = predict_sentiment(chunk)
                    results.append({
                        "comment":    chunk,
                        "rating":     "—",
                        "sentiment":  sentiment["label"],
                        "confidence": sentiment["confidence"],
                    })

        # build summary stats when we have results
        if results:
            pos = sum(1 for r in results if r["sentiment"] == "Positive")
            neg = len(results) - pos
            summary = {
                "total":    len(results),
                "positive": pos,
                "negative": neg,
                "pos_pct":  round(pos / len(results) * 100, 1),
            }

    # extract pain-point keywords from any negative results
    pain_points = _extract_pain_points(results) if results else []

    return render_template(
        "index.html",
        results=results,
        error=error,
        input_url=input_url,
        input_text=input_text,
        summary=summary,
        pain_points=pain_points,
    )


# ---------------------------------------------------------------------------
# Lightweight JSON API  (useful for testing / future front-end SPA)
# ---------------------------------------------------------------------------
@app.route("/api/predict", methods=["POST"])
def api_predict():
    data = request.get_json(silent=True) or {}
    text = (data.get("text") or "").strip()
    if not text:
        return jsonify({"error": "Provide a non-empty 'text' field."}), 400

    result = predict_sentiment(text)
    return jsonify(result)


# ---------------------------------------------------------------------------
# Health-check  (handy for AWS ALB / ECS target-group checks)
# ---------------------------------------------------------------------------
@app.route("/health")
def health():
    return jsonify({"status": "ok"}), 200


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app.run(debug=True)