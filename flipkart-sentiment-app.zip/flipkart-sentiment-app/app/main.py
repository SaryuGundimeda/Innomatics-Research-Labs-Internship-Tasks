"""
main.py – Flask application entry-point
=========================================
Two input modes
  1. Paste a Flipkart product-page URL  →  scrape & analyse every review.
  2. Type / paste review text manually  →  instant single-review prediction.

Routes
  GET  /          – render the UI
  POST /          – handle either mode (form submit)
  POST /api/predict – lightweight JSON endpoint for single-review prediction
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, render_template, request, jsonify
from scraper import get_reviews
from model  import predict_sentiment

app = Flask(__name__)


# ---------------------------------------------------------------------------
# Main page
# ---------------------------------------------------------------------------
@app.route("/", methods=["GET", "POST"])
def home():
    results      = []
    error        = None          # user-facing error message
    input_url    = ""
    input_text   = ""
    summary      = {}            # { total, positive, negative, pos_pct }

    if request.method == "POST":
        mode       = request.form.get("mode", "url")          # "url" | "text"
        input_url  = request.form.get("url", "").strip()
        input_text = request.form.get("review_text", "").strip()

        if mode == "url":
            # ── URL / scrape mode ──
            if not input_url:
                error = "Please paste a valid Flipkart product URL."
            else:
                reviews = get_reviews(input_url)
                if not reviews:
                    error = (
                        "Could not scrape reviews from the URL. "
                        "Flipkart may have blocked the request or the page "
                        "layout has changed. Try the Manual Text mode instead."
                    )
                else:
                    for r in reviews:
                        sentiment = predict_sentiment(r["comment"])
                        results.append({
                            "comment":    r["comment"],
                            "rating":     r["rating"],
                            "sentiment":  sentiment["label"],
                            "confidence": sentiment["confidence"],
                        })
        else:
            # ── Manual text mode ──
            if not input_text:
                error = "Please type or paste at least one review."
            else:
                # split on double-newline so users can paste several reviews
                chunks = [c.strip() for c in input_text.split("\n") if c.strip()]
                for chunk in chunks:
                    sentiment = predict_sentiment(chunk)
                    results.append({
                        "comment":    chunk,
                        "rating":     "—",
                        "sentiment":  sentiment["label"],
                        "confidence": sentiment["confidence"],
                    })

        # build summary stats when we have results
        if results:
            pos = sum(1 for r in results if r["sentiment"] == "Positive")
            neg = len(results) - pos
            summary = {
                "total":    len(results),
                "positive": pos,
                "negative": neg,
                "pos_pct":  round(pos / len(results) * 100, 1),
            }

    return render_template(
        "index.html",
        results=results,
        error=error,
        input_url=input_url,
        input_text=input_text,
        summary=summary,
    )


# ---------------------------------------------------------------------------
# Lightweight JSON API  (useful for testing / future front-end SPA)
# ---------------------------------------------------------------------------
@app.route("/api/predict", methods=["POST"])
def api_predict():
    data = request.get_json(silent=True) or {}
    text = (data.get("text") or "").strip()
    if not text:
        return jsonify({"error": "Provide a non-empty 'text' field."}), 400

    result = predict_sentiment(text)
    return jsonify(result)


# ---------------------------------------------------------------------------
# Health-check  (handy for AWS ALB / ECS target-group checks)
# ---------------------------------------------------------------------------
@app.route("/health")
def health():
    return jsonify({"status": "ok"}), 200


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app.run(debug=True)