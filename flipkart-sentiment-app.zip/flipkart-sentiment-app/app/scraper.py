"""
scraper.py – best-effort Flipkart review scraper.

Flipkart dynamically changes CSS class names, so we maintain several
selector sets and try each one.  If scraping fails for any reason
(network, anti-bot block, changed markup …) we return an empty list
so the UI can fall back to the manual-input path gracefully.
"""

import time
import requests
from bs4 import BeautifulSoup

# ---------------------------------------------------------------------------
# Selector sets – newest first.  Each tuple:
#   (review-block-tag, review-block-class,
#    comment-tag, comment-class,
#    rating-tag, rating-class)
# ---------------------------------------------------------------------------
SELECTOR_SETS = [
    # Set A – observed late-2024 / early-2025
    ("div", "_16PBlm",  "div", "t-ZTKy",   "div", "_3LWZlK"),
    # Set B – alternate class names seen on mobile Flipkart
    ("div", "col-2-4",  "div", "_2w8tUi",   "div", "_1j9MFe"),
    # Set C – another observed variant
    ("div", "_4dL5wz",  "div", "_2w8tUi",   "div", "_1j9MFe"),
]

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

MAX_RETRIES = 3
TIMEOUT     = 15   # seconds


def get_reviews(url: str) -> list[dict]:
    """
    Scrape reviews from *url*.

    Returns
    -------
    list[dict]
        Each dict has keys  "comment" (str)  and  "rating" (str).
        Returns an empty list on any failure.
    """
    html = _fetch(url)
    if html is None:
        return []

    soup = BeautifulSoup(html, "html.parser")

    for (blk_tag, blk_cls,
         cmt_tag, cmt_cls,
         rat_tag, rat_cls) in SELECTOR_SETS:

        blocks = soup.find_all(blk_tag, class_=blk_cls)
        if not blocks:
            continue                          # try next selector set

        reviews = []
        for block in blocks:
            comment_el = block.find(cmt_tag, class_=cmt_cls)
            rating_el  = block.find(rat_tag, class_=rat_cls)

            comment = (comment_el.get_text(strip=True) if comment_el else "").strip()
            rating  = (rating_el.get_text(strip=True)  if rating_el  else "").strip()

            if comment:                       # skip empty review bodies
                reviews.append({"comment": comment, "rating": rating or "N/A"})

        if reviews:
            return reviews                    # first matching set wins

    return []                                 # nothing matched


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _fetch(url: str) -> str | None:
    """GET with retries and timeout; returns raw HTML or None."""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
            resp.raise_for_status()
            return resp.text
        except requests.RequestException:
            if attempt < MAX_RETRIES:
                time.sleep(1 * attempt)       # back-off
            else:
                return None
    return None