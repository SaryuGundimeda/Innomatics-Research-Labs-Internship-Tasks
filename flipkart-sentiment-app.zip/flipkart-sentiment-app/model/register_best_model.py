"""
register_best_model.py - Register the best model to MLflow Model Registry
"""

import json
import os
import mlflow
from mlflow.tracking import MlflowClient

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(SCRIPT_DIR)
mlflow.set_tracking_uri("file:///" + os.path.join(REPO_ROOT, "mlruns"))

# Load metadata to get best run ID
with open(os.path.join(SCRIPT_DIR, "model_metadata.json"), "r") as f:
    meta = json.load(f)

best_run_id = meta["best_run_id"]
model_name = "flipkart-sentiment-classifier"

print(f"Registering model from run: {best_run_id}")

# Register model
model_uri = f"runs:/{best_run_id}/model"
model_details = mlflow.register_model(model_uri, model_name)

print(f"Model registered: {model_name}")
print(f"   Version: {model_details.version}")

# Add tags and description
client = MlflowClient()
client.update_model_version(
    name=model_name,
    version=model_details.version,
    description=f"Best model: {meta['best_model']} + {meta['best_vectoriser']} (F1-Macro: {meta['f1_macro']})"
)

client.set_model_version_tag(
    name=model_name,
    version=model_details.version,
    key="validation_status",
    value="approved"
)

client.set_model_version_tag(
    name=model_name,
    version=model_details.version,
    key="stage",
    value="production"
)

print(f"Model tagged and ready for production")