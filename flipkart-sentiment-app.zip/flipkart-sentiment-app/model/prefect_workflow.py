import os
from prefect import flow, task
import subprocess

@task(name="Load and Prepare Data", retries=2)
def prepare_data():
    """Load and clean the dataset"""
    import pandas as pd
    
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    REPO_ROOT = os.path.dirname(SCRIPT_DIR)
    DATA_PATH = os.path.join(REPO_ROOT, "data.csv")
    
    df = pd.read_csv(DATA_PATH)
    df.columns = [c.strip().lower() for c in df.columns]
    df["ratings"] = pd.to_numeric(df["ratings"], errors="coerce")
    df = df.dropna(subset=["ratings"])
    df = df[df["ratings"] != 3].copy()
    df["label"] = (df["ratings"] >= 4).astype(int)
    
    print(f"✅ Data prepared: {len(df)} samples")
    return len(df)

@task(name="Train Models with MLflow", retries=1)
def train_models():
    """Run the full training pipeline"""
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    train_script = os.path.join(SCRIPT_DIR, "train_model.py")
    
    result = subprocess.run(
        ["python", train_script],
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0:
        raise Exception(f"Training failed: {result.stderr}")
    
    print("✅ Training completed successfully")
    return result.returncode

@task(name="Register Best Model", retries=1)
def register_model():
    """Register the best model to MLflow registry"""
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    register_script = os.path.join(SCRIPT_DIR, "register_best_model.py")
    
    result = subprocess.run(
        ["python", register_script],
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0:
        raise Exception(f"Registration failed: {result.stderr}")
    
    print("✅ Model registered successfully")
    return result.returncode

@flow(name="Flipkart Sentiment Model Training Pipeline", log_prints=True)
def sentiment_training_pipeline():
    """Complete automated training pipeline"""
    print("🚀 Starting Flipkart Sentiment Training Pipeline")
    
    # Step 1: Prepare data
    sample_count = prepare_data()
    print(f"📊 Loaded {sample_count} samples")
    
    # Step 2: Train models
    train_models()
    
    # Step 3: Register best model
    register_model()
    
    print("✅ Pipeline completed successfully!")

if __name__ == "__main__":
    # Deploy with schedule - runs every Monday at 2 AM
    sentiment_training_pipeline.serve(
        name="weekly-sentiment-retraining",
        cron="0 2 * * 1",
        tags=["ml", "sentiment-analysis", "production"]
    )