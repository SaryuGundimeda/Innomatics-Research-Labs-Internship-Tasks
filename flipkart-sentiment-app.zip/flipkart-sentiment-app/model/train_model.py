"""
train_model.py  –  Flipkart Sentiment Classifier
=================================================
Dataset  : reviews_badminton/data.csv  (YONEX MAVIS 350 – 8 518 reviews)
Labels   : Rating 1-2 → Negative (0)  |  Rating 4-5 → Positive (1)
           Rating 3 rows are dropped (ambiguous / neutral)

Pipeline
  1. Text cleaning   – remove "READ MORE", punctuation, digits, stopwords
  2. Stemming        – lightweight suffix stripping (no nltk required)
  3. Vectorisation   – BoW  AND  TF-IDF  (both tested)
  4. Models          – Logistic Regression, Naive Bayes, Linear SVM,
                       Random Forest, Gradient Boosting
  5. Evaluation      – F1-Score (positive, negative, macro)
  6. Persistence     – best vectoriser → vectorizer.pkl
                       best classifier → classifier.pkl
                       comparison table → model_metadata.json

Run from the repo root:
    python model/train_model.py
"""

import csv, re, pickle, json, os, warnings
import numpy as np
import pandas as pd

from sklearn.feature_extraction.text import (
    CountVectorizer, TfidfVectorizer, ENGLISH_STOP_WORDS
)
from sklearn.linear_model          import LogisticRegression
from sklearn.svm                   import LinearSVC
from sklearn.ensemble              import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes           import MultinomialNB
from sklearn.model_selection       import train_test_split
from sklearn.metrics               import f1_score, classification_report, confusion_matrix

warnings.filterwarnings("ignore")

# ─── paths (works whether you run from repo-root or model/) ───
SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT   = os.path.dirname(SCRIPT_DIR)
DATA_PATH   = os.path.join(REPO_ROOT, "data.csv")
OUT_DIR     = SCRIPT_DIR                          # model/

# ═══════════════════════════════════════════════════════════════
# 1.  LOAD
# ═══════════════════════════════════════════════════════════════
df = pd.read_csv(DATA_PATH)
df.columns = [c.strip().lower() for c in df.columns]
print(f"[1] Loaded {len(df)} rows from data.csv")

# ═══════════════════════════════════════════════════════════════
# 2.  LABEL
# ═══════════════════════════════════════════════════════════════
df["ratings"] = pd.to_numeric(df["ratings"], errors="coerce")
df = df.dropna(subset=["ratings"])
df = df[df["ratings"] != 3].copy()                # drop neutral
df["label"] = (df["ratings"] >= 4).astype(int)    # 1=Pos 0=Neg
print(f"[2] After labelling: {len(df)} rows  "
      f"(Pos {(df['label']==1).sum()} | Neg {(df['label']==0).sum()})")

# ═══════════════════════════════════════════════════════════════
# 3.  TEXT CLEANING  +  STEMMING
# ═══════════════════════════════════════════════════════════════
EXTRA_STOP = {"read", "more", "flipkart", "certified", "buyer", "product"}
ALL_STOP   = ENGLISH_STOP_WORDS.union(EXTRA_STOP)

# Lightweight suffix list – covers the most common English inflections.
# Works well enough when combined with TF-IDF / BoW weighting.
_SUFFIXES = ["ingly","tion","sion","ment","ness","able","ible",
             "ous","ive","ful","less","ing","ed","ly","er","es","s"]

def stem(word: str) -> str:
    for s in _SUFFIXES:
        if word.endswith(s) and len(word) - len(s) >= 3:
            return word[: -len(s)]
    return word

def clean_text(text) -> str:
    if not isinstance(text, str):
        return ""
    text = text.replace("READ MORE", "")
    text = re.sub(r'[^\w\s]', ' ', text)          # punctuation  → space
    text = re.sub(r'\d+',    ' ', text)            # digits       → space
    text = re.sub(r'\s+',    ' ', text).strip().lower()
    tokens = [stem(t) for t in text.split()
              if t not in ALL_STOP and len(t) > 2]
    return " ".join(tokens)

df["clean_text"] = df["review text"].apply(clean_text)
df = df[df["clean_text"].str.len() > 0].copy()
print(f"[3] After cleaning: {len(df)} rows  (dropped {7903 - len(df)} empty texts)")

# ═══════════════════════════════════════════════════════════════
# 4.  SPLIT
# ═══════════════════════════════════════════════════════════════
X_text = df["clean_text"].values
y      = df["label"].values

X_train, X_test, y_train, y_test = train_test_split(
    X_text, y, test_size=0.2, random_state=42, stratify=y
)
print(f"[4] Train {len(X_train)} | Test {len(X_test)}")

# ═══════════════════════════════════════════════════════════════
# 5.  VECTORISE  (BoW  &  TF-IDF)
# ═══════════════════════════════════════════════════════════════
bow_vec   = CountVectorizer(max_features=10000, ngram_range=(1,2), stop_words='english')
tfidf_vec = TfidfVectorizer(max_features=10000, ngram_range=(1,2),
                            sublinear_tf=True, stop_words='english')

X_train_bow   = bow_vec.fit_transform(X_train);  X_test_bow   = bow_vec.transform(X_test)
X_train_tfidf = tfidf_vec.fit_transform(X_train); X_test_tfidf = tfidf_vec.transform(X_test)
print(f"[5] BoW {X_train_bow.shape} | TF-IDF {X_train_tfidf.shape}")

# ═══════════════════════════════════════════════════════════════
# 6.  TRAIN + EVALUATE  (5 models × 2 vectorisers = 10 combos)
# ═══════════════════════════════════════════════════════════════
MODEL_DEFS = {
    "Logistic Regression" : lambda: LogisticRegression(C=10, max_iter=1000, class_weight='balanced'),
    "Naive Bayes"         : lambda: MultinomialNB(alpha=0.1),
    "Linear SVM"          : lambda: LinearSVC(C=1, max_iter=5000, class_weight='balanced'),
    "Random Forest"       : lambda: RandomForestClassifier(n_estimators=200, max_depth=30,
                                                           class_weight='balanced', random_state=42),
    "Gradient Boosting"   : lambda: GradientBoostingClassifier(n_estimators=200, max_depth=5, random_state=42),
}

results = []

for vec_name, X_tr, X_te in [("BoW",    X_train_bow,   X_test_bow),
                              ("TF-IDF", X_train_tfidf, X_test_tfidf)]:
    print(f"\n  ── {vec_name} ──")
    for model_name, model_fn in MODEL_DEFS.items():
        mdl = model_fn()
        mdl.fit(X_tr, y_train)
        y_pred = mdl.predict(X_te)

        f1_pos   = f1_score(y_test, y_pred, pos_label=1)
        f1_neg   = f1_score(y_test, y_pred, pos_label=0)
        f1_macro = f1_score(y_test, y_pred, average='macro')

        results.append(dict(vectoriser=vec_name, model=model_name,
                            f1_pos=round(f1_pos,4), f1_neg=round(f1_neg,4),
                            f1_macro=round(f1_macro,4)))
        print(f"    {model_name:25s} | F1-Pos {f1_pos:.4f} | F1-Neg {f1_neg:.4f} | F1-Macro {f1_macro:.4f}")

# ═══════════════════════════════════════════════════════════════
# 7.  PICK BEST  (highest macro-F1)
# ═══════════════════════════════════════════════════════════════
results_df = pd.DataFrame(results).sort_values("f1_macro", ascending=False)
print("\n" + "═"*70)
print("  COMPARISON TABLE  (sorted by F1-Macro)")
print("═"*70)
print(results_df.to_string(index=False))

best = results_df.iloc[0]
print(f"\n🏆  BEST: {best['model']} + {best['vectoriser']}  (F1-Macro = {best['f1_macro']})")

# ═══════════════════════════════════════════════════════════════
# 8.  RETRAIN BEST on train split → full classification report
# ═══════════════════════════════════════════════════════════════
if best["vectoriser"] == "BoW":
    final_vec = CountVectorizer(max_features=10000, ngram_range=(1,2), stop_words='english')
else:
    final_vec = TfidfVectorizer(max_features=10000, ngram_range=(1,2),
                                sublinear_tf=True, stop_words='english')

X_tr_f = final_vec.fit_transform(X_train)
X_te_f = final_vec.transform(X_test)

final_clf = MODEL_DEFS[best["model"]]()
final_clf.fit(X_tr_f, y_train)

y_pred_final = final_clf.predict(X_te_f)

print("\n" + "═"*70)
print(f"  CLASSIFICATION REPORT  –  {best['model']} + {best['vectoriser']}")
print("═"*70)
print(classification_report(y_test, y_pred_final, target_names=["Negative","Positive"]))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred_final))

# ═══════════════════════════════════════════════════════════════
# 9.  PERSIST
# ═══════════════════════════════════════════════════════════════
pickle.dump(final_vec, open(os.path.join(OUT_DIR, "vectorizer.pkl"), "wb"))
pickle.dump(final_clf, open(os.path.join(OUT_DIR, "classifier.pkl"), "wb"))

meta = {
    "best_model"      : best["model"],
    "best_vectoriser" : best["vectoriser"],
    "f1_macro"        : best["f1_macro"],
    "all_results"     : results_df.to_dict(orient="records"),
    "label_mapping"   : {"0": "Negative (Rating 1-2)", "1": "Positive (Rating 4-5)"},
    "dataset"         : "data.csv  (YONEX MAVIS 350 Nylon Shuttle – Flipkart)",
    "total_samples"   : len(df),
}
with open(os.path.join(OUT_DIR, "model_metadata.json"), "w") as f:
    json.dump(meta, f, indent=2)

print(f"\n✅  vectorizer.pkl, classifier.pkl, model_metadata.json → {OUT_DIR}")
