"""
train_model.py  –  Flipkart Sentiment Classifier with MLflow
============================================================
Trains 5 models × 2 vectorisers (10 combos) and logs everything to MLflow:
  - Parameters: vectoriser type, model name, hyperparameters
  - Metrics: F1-Score (pos, neg, macro), accuracy
  - Artifacts: vectorizer.pkl, classifier.pkl, confusion matrix plot
  - Tags: best_model flag for the winning combo
"""

import csv
import re
import pickle
import json
import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import mlflow
import mlflow.sklearn
from mlflow.models.signature import infer_signature

from sklearn.feature_extraction.text import (
    CountVectorizer, TfidfVectorizer, ENGLISH_STOP_WORDS
)
from sklearn.linear_model          import LogisticRegression
from sklearn.svm                   import LinearSVC
from sklearn.ensemble              import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes           import MultinomialNB
from sklearn.model_selection       import train_test_split
from sklearn.metrics               import f1_score, classification_report, confusion_matrix, accuracy_score

warnings.filterwarnings("ignore")

# Setup paths
SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT   = os.path.dirname(SCRIPT_DIR)
DATA_PATH   = os.path.join(REPO_ROOT, "data.csv")
OUT_DIR     = SCRIPT_DIR

# MLflow setup
mlflow.set_tracking_uri("file:///" + os.path.join(REPO_ROOT, "mlruns"))
mlflow.set_experiment("flipkart-sentiment-analysis")

# Text cleaning pipeline
EXTRA_STOP = {"read", "more", "flipkart", "certified", "buyer", "product"}
ALL_STOP   = ENGLISH_STOP_WORDS.union(EXTRA_STOP)

_SUFFIXES = ["ingly","tion","sion","ment","ness","able","ible",
             "ous","ive","ful","less","ing","ed","ly","er","es","s"]

def stem(word: str) -> str:
    for s in _SUFFIXES:
        if word.endswith(s) and len(word) - len(s) >= 3:
            return word[: -len(s)]
    return word

def clean_text(text) -> str:
    if not isinstance(text, str):
        return ""
    text = text.replace("READ MORE", "")
    text = re.sub(r'[^\w\s]', ' ', text)
    text = re.sub(r'\d+',    ' ', text)
    text = re.sub(r'\s+',    ' ', text).strip().lower()
    tokens = [stem(t) for t in text.split() if t not in ALL_STOP and len(t) > 2]
    return " ".join(tokens)

# Load and prepare data
df = pd.read_csv(DATA_PATH)
df.columns = [c.strip().lower() for c in df.columns]
df["ratings"] = pd.to_numeric(df["ratings"], errors="coerce")
df = df.dropna(subset=["ratings"])
df = df[df["ratings"] != 3].copy()
df["label"] = (df["ratings"] >= 4).astype(int)
df["clean_text"] = df["review text"].apply(clean_text)
df = df[df["clean_text"].str.len() > 0].copy()

print(f"[DATA] Loaded {len(df)} samples  (Pos: {(df['label']==1).sum()} | Neg: {(df['label']==0).sum()})")

X_text = df["clean_text"].values
y      = df["label"].values

X_train, X_test, y_train, y_test = train_test_split(
    X_text, y, test_size=0.2, random_state=42, stratify=y
)

# Model definitions with hyperparameters
MODEL_CONFIGS = {
    "Logistic Regression": {
        "model": LogisticRegression,
        "params": {"C": 10, "max_iter": 1000, "class_weight": "balanced", "solver": "lbfgs"}
    },
    "Naive Bayes": {
        "model": MultinomialNB,
        "params": {"alpha": 0.1}
    },
    "Linear SVM": {
        "model": LinearSVC,
        "params": {"C": 1, "max_iter": 5000, "class_weight": "balanced"}
    },
    "Random Forest": {
        "model": RandomForestClassifier,
        "params": {"n_estimators": 200, "max_depth": 30, "class_weight": "balanced", "random_state": 42}
    },
    "Gradient Boosting": {
        "model": GradientBoostingClassifier,
        "params": {"n_estimators": 200, "max_depth": 5, "learning_rate": 0.1, "random_state": 42}
    }
}

VECTORIZER_CONFIGS = {
    "BoW": {
        "class": CountVectorizer,
        "params": {"max_features": 10000, "ngram_range": (1,2), "stop_words": "english"}
    },
    "TF-IDF": {
        "class": TfidfVectorizer,
        "params": {"max_features": 10000, "ngram_range": (1,2), "sublinear_tf": True, "stop_words": "english"}
    }
}

# Training loop with MLflow tracking
results = []
best_f1 = 0
best_run_id = None

for vec_name, vec_config in VECTORIZER_CONFIGS.items():
    # Fit vectorizer
    vectorizer = vec_config["class"](**vec_config["params"])
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    
    for model_name, model_config in MODEL_CONFIGS.items():
        run_name = f"{model_name} + {vec_name}"
        
        with mlflow.start_run(run_name=run_name):
            print(f"\n[TRAINING] {run_name}")
            
            # Log parameters
            mlflow.log_param("vectorizer", vec_name)
            mlflow.log_param("model", model_name)
            for k, v in vec_config["params"].items():
                mlflow.log_param(f"vec_{k}", v)
            for k, v in model_config["params"].items():
                mlflow.log_param(f"model_{k}", v)
            
            # Train model
            clf = model_config["model"](**model_config["params"])
            clf.fit(X_train_vec, y_train)
            y_pred = clf.predict(X_test_vec)
            
            # Calculate metrics
            f1_pos = f1_score(y_test, y_pred, pos_label=1)
            f1_neg = f1_score(y_test, y_pred, pos_label=0)
            f1_macro = f1_score(y_test, y_pred, average='macro')
            accuracy = accuracy_score(y_test, y_pred)
            
            # Log metrics
            mlflow.log_metric("f1_positive", f1_pos)
            mlflow.log_metric("f1_negative", f1_neg)
            mlflow.log_metric("f1_macro", f1_macro)
            mlflow.log_metric("accuracy", accuracy)
            
            # Create and log confusion matrix plot
            cm = confusion_matrix(y_test, y_pred)
            fig, ax = plt.subplots(figsize=(8, 6))
            im = ax.imshow(cm, cmap='Blues')
            ax.set_xticks([0, 1])
            ax.set_yticks([0, 1])
            ax.set_xticklabels(['Negative', 'Positive'])
            ax.set_yticklabels(['Negative', 'Positive'])
            plt.colorbar(im, ax=ax)
            for i in range(2):
                for j in range(2):
                    ax.text(j, i, str(cm[i, j]), ha='center', va='center', color='red', fontsize=20)
            ax.set_xlabel('Predicted')
            ax.set_ylabel('Actual')
            ax.set_title(f'Confusion Matrix - {run_name}')
            
            cm_path = os.path.join(OUT_DIR, f"confusion_matrix_{vec_name}_{model_name.replace(' ', '_')}.png")
            plt.savefig(cm_path, dpi=100, bbox_inches='tight')
            plt.close()
            mlflow.log_artifact(cm_path)
            os.remove(cm_path)
            
            # Log model with signature
            try:
                sample_input = X_test_vec[:5]
                sample_output = clf.predict(sample_input)
                signature = infer_signature(sample_input, sample_output)
                mlflow.sklearn.log_model(clf, "model", signature=signature)
            except:
                mlflow.sklearn.log_model(clf, "model")
            
            # Save vectorizer as artifact
            vec_path = os.path.join(OUT_DIR, "temp_vectorizer.pkl")
            with open(vec_path, "wb") as f:
                pickle.dump(vectorizer, f)
            mlflow.log_artifact(vec_path, "vectorizer")
            os.remove(vec_path)
            
            # Track best model
            if f1_macro > best_f1:
                best_f1 = f1_macro
                best_run_id = mlflow.active_run().info.run_id
                mlflow.set_tag("best_model", "true")
                
                # Save best model files
                with open(os.path.join(OUT_DIR, "vectorizer.pkl"), "wb") as f:
                    pickle.dump(vectorizer, f)
                with open(os.path.join(OUT_DIR, "classifier.pkl"), "wb") as f:
                    pickle.dump(clf, f)
            else:
                mlflow.set_tag("best_model", "false")
            
            results.append({
                "run_id": mlflow.active_run().info.run_id,
                "vectoriser": vec_name,
                "model": model_name,
                "f1_pos": round(f1_pos, 4),
                "f1_neg": round(f1_neg, 4),
                "f1_macro": round(f1_macro, 4),
                "accuracy": round(accuracy, 4)
            })
            
            print(f"  F1-Pos: {f1_pos:.4f} | F1-Neg: {f1_neg:.4f} | F1-Macro: {f1_macro:.4f} | Accuracy: {accuracy:.4f}")

# Print summary and save metadata
results_df = pd.DataFrame(results).sort_values("f1_macro", ascending=False)
print("\n" + "═"*80)
print("  RESULTS SUMMARY (sorted by F1-Macro)")
print("═"*80)
print(results_df.to_string(index=False))

best = results_df.iloc[0]
print(f"\n🏆 BEST: {best['model']} + {best['vectoriser']} (F1-Macro: {best['f1_macro']})")
print(f"   Run ID: {best['run_id']}")

# Save metadata
meta = {
    "best_model": best["model"],
    "best_vectoriser": best["vectoriser"],
    "best_run_id": best["run_id"],
    "f1_macro": best["f1_macro"],
    "all_results": results_df.to_dict(orient="records"),
    "mlflow_tracking_uri": mlflow.get_tracking_uri()
}
with open(os.path.join(OUT_DIR, "model_metadata.json"), "w") as f:
    json.dump(meta, f, indent=2)

print(f"\n✅ MLflow tracking URI: {mlflow.get_tracking_uri()}")
print(f"✅ Run: mlflow ui --backend-store-uri {mlflow.get_tracking_uri()}")
print(f"✅ Best model saved to {OUT_DIR}")