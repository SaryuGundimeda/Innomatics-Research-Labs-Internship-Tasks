# Flipkart Sentiment Analyzer – AWS EC2 Deployment (Free Tier, Beginner Guide)

Everything below is free. AWS gives 750 hours/month of t2.micro for 12 months — that is more than enough.

---

## PART 1 – Create an AWS Account (5 min)

1. Go to **https://aws.amazon.com** → click **Create an AWS account** (top right).
2. Enter your email and choose a username.
3. Select **Individual** account type.
4. Fill in your name, address, phone number.
5. Add a credit/debit card. You will NOT be charged as long as you stick to free-tier services. They only charge if you exceed free limits.
6. Verify your phone number via OTP.
7. Choose the **Basic (free) Support Plan**.
8. Done — you land on the AWS Management Console.

---

## PART 2 – Launch an EC2 Instance (5 min)

1. In the console, the search bar at the top says *"Search for services…"* → type **EC2** → click the first result.
2. Click the orange **Launch instances** button.
3. Fill in the form:

| Field | What to pick |
|-------|--------------|
| Name | `flipkart-sentiment-app` |
| OS / AMI | **Ubuntu** (scroll down, pick **Ubuntu 22.04 LTS** – 64-bit) |
| Instance type | **t2.micro** (it already says "Free tier eligible") |
| Key pair | Click **Create a new key pair** → name it `mykey` → click **Create** (downloads `mykey.pem` — keep this file safe, you need it to SSH in) |
| Security group | Click **Create security group** |

4. Under the security group section you just created, click **Add ingress rule**:

| Type | Protocol | Port | Source |
|------|----------|------|--------|
| HTTP | TCP | 80 | 0.0.0.0/0 |
| SSH | TCP | 22 | 0.0.0.0/0 |

5. Scroll down → click the orange **Launch instance** button.
6. Wait 10–15 seconds. Click **View instances**. You'll see your instance with a green **running** status and a **Public IPv4 address** like `54.123.45.67`. Copy that IP — you'll need it.

---

## PART 3 – Upload Your Project Files (3 min)

You need to get the zip file onto the server. The easiest way on Mac:

```bash
# Replace 54.123.45.67 with YOUR actual public IP from step 6 above
# Replace ~/Downloads/mykey.pem with the path where your key downloaded
# Replace ~/path/to/flipkart-sentiment-app.zip with your actual zip path

scp -i ~/Downloads/mykey.pem ~/path/to/flipkart-sentiment-app.zip ubuntu@54.123.45.67:/home/ubuntu/
```

Run that one command in your terminal. It uploads the zip to the server.

---

## PART 4 – SSH Into the Server and Set Up (10 min)

Run these commands one by one. Each one does exactly what the comment says.

```bash
# ── 1. Connect to the server
ssh -i ~/Downloads/mykey.pem ubuntu@54.123.45.67

# ── 2. Update the server's package list
sudo apt update

# ── 3. Install Python 3.11 and pip
sudo apt install -y python3.11 python3.11-venv python3-pip unzip

# ── 4. Unzip your project
cd /home/ubuntu
unzip flipkart-sentiment-app.zip
cd flipkart-sentiment-app

# ── 5. Create a virtual environment and activate it
python3.11 -m venv venv
source venv/bin/activate

# ── 6. Install all dependencies
pip install -r requirements.txt

# ── 7. Train the model (this prints the F1 scores and saves the pkl files)
python model/train_model.py

# ── 8. Test that the app starts (it will print "Running on http://0.0.0.0:5000")
#       Press Ctrl+C after 2 seconds — this is just a quick sanity check
cd app
python main.py
# (press Ctrl+C here)
cd ..
```

If step 8 printed "Running on…" without any errors, everything is installed correctly.

---

## PART 5 – Run the App Permanently with Gunicorn (3 min)

`python main.py` stops the moment you close the terminal. Gunicorn keeps it alive forever in the background.

```bash
# Make sure you are in the project root and venv is active
cd /home/ubuntu/flipkart-sentiment-app
source venv/bin/activate

# Start gunicorn on port 80 in the background
# The "&" at the end means "run in background, don't block the terminal"
cd app
gunicorn -w 2 -b 0.0.0.0:80 main:app &
```

That's it. The app is now live.

---

## PART 6 – Open It in Your Browser

Open any browser and go to:

```
http://54.123.45.67
```

Replace `54.123.45.67` with your actual EC2 public IP. You should see the Flipkart Sentiment Analyzer UI.

Test it: click **Manual Text**, paste *"Worst product ever, completely fake shuttlecocks"*, hit **Analyze Sentiment**.

---

## PART 7 – Keep It Running After Reboot (optional but good practice)

If the EC2 instance restarts, gunicorn dies. This sets it up to auto-start:

```bash
# still SSH'd into the server
sudo nano /etc/systemd/system/flipkart.service
```

A text editor opens. Paste this exactly (change nothing):

```
[Unit]
Description=Flipkart Sentiment App

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/flipkart-sentiment-app/app
ExecStart=/home/ubuntu/flipkart-sentiment-app/venv/bin/gunicorn -w 2 -b 0.0.0.0:80 main:app

[Install]
WantedBy=multi-user.target
```

Save and close: press **Ctrl+S**, then **Ctrl+X**.

```bash
sudo systemctl daemon-reload
sudo systemctl enable flipkart
sudo systemctl start flipkart
```

Done. Now it survives reboots.

---

## PART 8 – Stop Everything When You're Done (saves money)

Go back to the AWS Console → EC2 → Instances → select your instance → click **Instance state** → **Terminate instance**.

This permanently deletes it and stops all charges. Do this once your submission is done.

---

## Quick Reference – All Terminal Commands In Order

```bash
# ── on your Mac (upload the file) ──
scp -i ~/Downloads/mykey.pem ~/path/to/flipkart-sentiment-app.zip ubuntu@YOUR_IP:/home/ubuntu/

# ── on the server (SSH in first, then run these one by one) ──
ssh -i ~/Downloads/mykey.pem ubuntu@YOUR_IP
sudo apt update
sudo apt install -y python3.11 python3.11-venv python3-pip unzip
cd /home/ubuntu
unzip flipkart-sentiment-app.zip
cd flipkart-sentiment-app
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python model/train_model.py
cd app
gunicorn -w 2 -b 0.0.0.0:80 main:app &

# ── open in browser ──
# http://YOUR_IP
```

Replace `YOUR_IP` everywhere with the Public IPv4 address shown on your EC2 instance page.
