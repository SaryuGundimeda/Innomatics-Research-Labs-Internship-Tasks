"""
Serene - Mental Health Support Chatbot
Main UI entry point using Streamlit.
Run with: streamlit run app.py
"""

import streamlit as st
from dotenv import load_dotenv

# Load environment variables from .env file FIRST (before any other imports)
load_dotenv()

from config.prompts import WELCOME_MESSAGE
from modules.gemini_handler import initialize_gemini, start_chat_session, send_message
from modules.session_manager import (
    initialize_session_state,
    add_message,
    get_history_for_gemini,
    clear_session
)

# ── Page Configuration ────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Serene - Mental Health Support",
    page_icon="💙",
    layout="centered",
    initial_sidebar_state="expanded"
)

# ── Custom CSS Styling ────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Main background */
    .stApp {
        background: linear-gradient(135deg, #f0f4ff 0%, #faf0ff 100%);
    }
    
    /* Chat message containers */
    .user-message {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        padding: 12px 16px;
        border-radius: 18px 18px 4px 18px;
        margin: 8px 0;
        max-width: 80%;
        margin-left: auto;
        word-wrap: break-word;
    }
    
    .bot-message {
        background: white;
        color: #2d3748;
        padding: 12px 16px;
        border-radius: 18px 18px 18px 4px;
        margin: 8px 0;
        max-width: 85%;
        border-left: 4px solid #667eea;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        word-wrap: break-word;
    }
    
    .timestamp {
        font-size: 11px;
        color: #a0aec0;
        margin-top: 4px;
    }
    
    /* Header */
    .main-header {
        text-align: center;
        padding: 20px 0 10px;
    }
    
    /* Input area */
    .stTextInput > div > div > input {
        border-radius: 25px;
        border: 2px solid #667eea;
        padding: 10px 20px;
    }
    
    /* Sidebar */
    .sidebar-info {
        background: white;
        padding: 12px;
        border-radius: 10px;
        margin-bottom: 10px;
        border-left: 3px solid #667eea;
        font-size: 13px;
    }
    
    /* Crisis banner */
    .crisis-banner {
        background: #fff5f5;
        border: 1px solid #fc8181;
        border-radius: 8px;
        padding: 10px 14px;
        font-size: 13px;
        color: #c53030;
    }
</style>
""", unsafe_allow_html=True)


# ── Initialize Session State ──────────────────────────────────────────────────
initialize_session_state(st)


# ── Initialize Gemini Model (once per session) ────────────────────────────────
if st.session_state.model is None:
    try:
        st.session_state.model = initialize_gemini()
    except EnvironmentError as e:
        st.error(f"⚠️ Configuration Error: {e}")
        st.info("Create a `.env` file in the project root with: `GEMINI_API_KEY=your_key_here`")
        st.stop()


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 💙 Serene")
    st.markdown("*Your Mental Health Companion*")
    st.divider()

    # Crisis Resources (always visible)
    st.markdown("""
    <div class="crisis-banner">
    🆘 <strong>In Crisis?</strong><br>
    📞 Call/Text <strong>988</strong><br>
    💬 Text HOME to <strong>741741</strong><br>
    <a href="https://988lifeline.org" target="_blank">988lifeline.org</a>
    </div>
    """, unsafe_allow_html=True)

    st.divider()

    # Session info
    st.markdown("### Session Info")
    st.markdown(f"""
    <div class="sidebar-info">
    Started: {st.session_state.session_start_time}<br>
    Messages: {st.session_state.message_count}
    </div>
    """, unsafe_allow_html=True)

    # Conversation starters
    st.markdown("### Conversation Starters")
    starters = [
        "I've been feeling anxious lately",
        "I'm having trouble sleeping",
        "I need help with stress management",
        "I'm feeling overwhelmed",
        "Can you teach me a breathing exercise?"
    ]
    for starter in starters:
        if st.button(starter, key=f"starter_{starter}", use_container_width=True):
            st.session_state["pending_starter"] = starter

    st.divider()

    # Clear conversation button
    if st.button("Start New Conversation", use_container_width=True, type="secondary"):
        clear_session(st)
        st.rerun()

    st.markdown("""
    <div class="sidebar-info">
    ℹ<strong>Disclaimer:</strong> Serene is an AI assistant, not a licensed therapist. 
    For serious mental health concerns, please consult a healthcare professional.
    </div>
    """, unsafe_allow_html=True)


# ── Main Chat Interface ───────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>💙 Serene</h1>
    <p style="color: #718096; font-size: 16px;">A safe space to talk, reflect, and find support</p>
</div>
""", unsafe_allow_html=True)

# Chat history display container
chat_container = st.container()

with chat_container:
    # Show welcome message if no history
    if not st.session_state.chat_history:
        st.markdown(f"""
        <div class="bot-message">
        {WELCOME_MESSAGE.replace(chr(10), '<br>')}
        </div>
        """, unsafe_allow_html=True)
    else:
        # Display all messages
        for msg in st.session_state.chat_history:
            if msg["role"] == "user":
                st.markdown(f"""
                <div class="user-message">
                    {msg['content']}
                    <div class="timestamp">{msg.get('timestamp', '')}</div>
                </div>
                """, unsafe_allow_html=True)
            else:
                # Convert newlines to HTML breaks for bot messages
                content = msg['content'].replace('\n', '<br>')
                st.markdown(f"""
                <div class="bot-message">
                    {content}
                    <div class="timestamp">Serene · {msg.get('timestamp', '')}</div>
                </div>
                """, unsafe_allow_html=True)


# ── Message Input ─────────────────────────────────────────────────────────────
st.markdown("<br>", unsafe_allow_html=True)

# Handle conversation starter buttons from sidebar
prefill_value = st.session_state.pop("pending_starter", "")

with st.form(key="chat_form", clear_on_submit=True):
    col1, col2 = st.columns([5, 1])
    with col1:
        user_input = st.text_input(
            label="Message",
            value=prefill_value,
            placeholder="Share what's on your mind...",
            label_visibility="collapsed"
        )
    with col2:
        submit = st.form_submit_button("Send 💙", use_container_width=True, type="primary")


# ── Process Message ───────────────────────────────────────────────────────────
if submit and user_input and user_input.strip():
    # Add user message to history
    add_message(st, "user", user_input.strip())

    # Show loading indicator while getting response
    with st.spinner("Serene is thinking..."):
        # Start or continue Gemini chat session
        if st.session_state.gemini_session is None:
            history = get_history_for_gemini(st)
            # Don't include the message we just added in the history passed to Gemini
            # (we'll send it as the new message)
            prior_history = history[:-1] if history else []
            st.session_state.gemini_session = start_chat_session(
                st.session_state.model,
                prior_history
            )

        # Get response from Gemini
        response = send_message(st.session_state.gemini_session, user_input.strip())

    # Add bot response to history
    add_message(st, "assistant", response)

    # Rerun to refresh the chat display
    st.rerun()
