# 💙 Serene — Mental Health Support Chatbot

A production-ready, domain-specific AI chatbot for mental health support, built with Google Gemini GenAI API and Streamlit. Designed following real-world AI engineering standards.

---

## Project Structure

```
mental_health_chatbot/
│
├── app.py                    ← Main Streamlit UI (entry point)
├── requirements.txt          ← Python dependencies
├── .env.example              ← Template for your API key (copy to .env)
├── .env                      ← YOUR secrets (never commit this!)
├── .gitignore                ← Keeps secrets out of Git
│
├── config/
│   ├── __init__.py
│   └── prompts.py            ← All system prompts (configurable)
│
└── modules/
    ├── __init__.py
    ├── gemini_handler.py     ← Gemini API logic (separated from UI)
    └── session_manager.py    ← Conversation memory & session state
```

### Architecture Diagram

```
User Input (Streamlit UI)
        │
        ▼
session_manager.py  ←── Stores & retrieves conversation history
        │
        ▼
gemini_handler.py   ←── Formats request, handles errors, logs usage
        │
        ▼
config/prompts.py   ←── Injects system prompt & role instructions
        │
        ▼
Google Gemini API   ←── Generates response
        │
        ▼
gemini_handler.py   ←── Processes & validates response
        │
        ▼
session_manager.py  ←── Saves response to history
        │
        ▼
Streamlit UI        ←── Renders response in chat interface
```

---

## Local Setup (Step-by-Step)

### Step 1 — Prerequisites

Make sure you have these installed. Open a terminal and check:

```bash
python --version    # Need 3.9 or higher
pip --version       # Comes with Python
git --version       # For version control
```

If Python isn't installed, download it from https://python.org.

---

### Step 2 — Get Your Gemini API Key (FREE)

1. Go to **https://aistudio.google.com/app/apikey**
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Copy the key — it looks like: `AIzaSyABC123...`

> **Keep this secret!** Never share it or put it in your code directly.

---

### Step 3 — Download & Set Up the Project

```bash
# Clone from GitHub (or download the ZIP)
git clone https://github.com/YOUR_USERNAME/mental-health-chatbot.git
cd mental_health_chatbot

# Create a virtual environment (keeps your project dependencies isolated)
python -m venv venv

# Activate it:
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

---

### Step 4 — Set Up Your API Key

Create a file called `.env` in the project root folder:

```bash
# In your terminal (or create the file manually in VS Code)
copy .env.example .env       # Windows
# OR
cp .env.example .env         # Mac/Linux
```

Now open `.env` in VS Code and replace the placeholder:

```
GEMINI_API_KEY=AIzaSyYOUR_ACTUAL_KEY_HERE
```

> Your `.gitignore` already prevents this file from being pushed to GitHub.

---

### Step 5 — Run the App

```bash
streamlit run app.py
```

Your browser will open automatically at **http://localhost:8501** 🎉

---

## AWS EC2 Deployment (Step-by-Step)

### Step 1 — Launch an EC2 Instance

1. Go to **https://console.aws.amazon.com/ec2**
2. Click **"Launch Instance"**
3. Configure:
   - **Name:** `serene-chatbot`
   - **AMI:** Ubuntu Server 22.04 LTS (Free Tier)
   - **Instance Type:** t2.micro (Free Tier eligible)
   - **Key Pair:** Create new → download the `.pem` file (keep it safe!)
   - **Security Group:** Click "Edit" and add these rules:

| Type | Protocol | Port | Source |
|------|----------|------|--------|
| SSH | TCP | 22 | My IP |
| Custom TCP | TCP | 8501 | 0.0.0.0/0 |

4. Click **"Launch Instance"**

---

### Step 2 — Connect to Your EC2 Instance

```bash
# Fix permissions on your key file (Mac/Linux only)
chmod 400 your-key.pem

# Connect (replace with your actual Public IP from AWS console)
ssh -i your-key.pem ubuntu@YOUR_EC2_PUBLIC_IP
```

On Windows, use **PuTTY** or the **VS Code Remote SSH** extension.

---

### Step 3 — Set Up the Server

```bash
# Update the system
sudo apt update && sudo apt upgrade -y

# Install Python and pip
sudo apt install python3-pip python3-venv git -y

# Clone your project
git clone https://github.com/YOUR_USERNAME/mental-health-chatbot.git
cd mental_health_chatbot

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

---

### Step 4 — Set Environment Variable on EC2

```bash
# Set the API key as an environment variable on the server
# (DO NOT create a .env file with your key on a public server — use this instead)
export GEMINI_API_KEY="AIzaSyYOUR_ACTUAL_KEY_HERE"

# To make it permanent across reboots, add to ~/.bashrc:
echo 'export GEMINI_API_KEY="AIzaSyYOUR_ACTUAL_KEY_HERE"' >> ~/.bashrc
source ~/.bashrc
```

---

### Step 5 — Run the App as a Background Process

```bash
# Run Streamlit in the background so it keeps running after you disconnect
nohup streamlit run app.py --server.port 8501 --server.address 0.0.0.0 > streamlit.log 2>&1 &

# Verify it's running
ps aux | grep streamlit

# Check logs if needed
tail -f streamlit.log
```

---

### Step 6 — Access Your Live App

Open your browser and go to:

```
http://YOUR_EC2_PUBLIC_IP:8501
```

Find your Public IP in the AWS EC2 console under "Instances" → click your instance → "Public IPv4 address".

---

### Stopping the App

```bash
# Find the process ID
ps aux | grep streamlit

# Kill it (replace 12345 with actual PID)
kill 12345
```

---

## 🔧 Configuration

All prompts are in `config/prompts.py` — edit there to change the chatbot's personality, tone, or domain constraints without touching any other code.

---

## Security Best Practices

- API key loaded from environment variables only
- `.env` file excluded from Git via `.gitignore`
- No credentials hardcoded anywhere in the codebase
- EC2 Security Group restricts SSH to your IP only
- Gemini safety filters enabled for harmful content

---

## Dependencies

| Package | Purpose |
|---------|---------|
| `streamlit` | Interactive web UI |
| `google-generativeai` | Gemini API client |
| `python-dotenv` | Load `.env` file securely |

---

## Key Features

- **Multi-turn memory** — conversation context preserved across turns
- **Advanced prompt engineering** — structured system prompt with role, constraints, and crisis protocol
- **Modular architecture** — UI, API, prompts, and session all in separate modules
- **Full exception handling** — graceful fallbacks for all API errors
- **Token optimization** — max output tokens capped, history pruned automatically
- **API call logging** — all requests, responses, and token usage logged to `chatbot.log`
- **Crisis resources** — always visible in sidebar, auto-triggered on crisis keywords

---

## Disclaimer

Serene is an AI assistant for informational and emotional support purposes only. It is not a substitute for professional mental health care. If you or someone you know is in crisis, please contact **988** (Suicide & Crisis Lifeline) immediately.
