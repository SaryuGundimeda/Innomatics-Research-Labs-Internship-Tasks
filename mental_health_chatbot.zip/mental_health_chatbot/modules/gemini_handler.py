"""
Gemini API Handler Module
Handles all interactions with the Google Gemini API.
This module is completely separate from the UI layer.
"""

import os
import logging
import google.generativeai as genai
from config.prompts import SYSTEM_PROMPT

# ── Logging Setup ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("chatbot.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# ── Gemini Client Initialization ──────────────────────────────────────────────
def initialize_gemini():
    """
    Load the API key from environment variables and configure the Gemini client.
    NEVER hardcode your API key — always load from environment.
    """
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        logger.error("GEMINI_API_KEY environment variable not set.")
        raise EnvironmentError(
            "GEMINI_API_KEY is not set. "
            "Please add it to your .env file or export it in your terminal."
        )
    genai.configure(api_key=api_key)
    logger.info("Gemini API initialized successfully.")
    return genai.GenerativeModel(
        model_name="gemini-2.0-flash",
        system_instruction=SYSTEM_PROMPT,
        generation_config={
            "temperature": 0.7,       # Balanced: not too robotic, not too random
            "top_p": 0.9,
            "top_k": 40,
            "max_output_tokens": 1024,  # Token optimization: limit response length
        },
        safety_settings=[
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_ONLY_HIGH"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        ]
    )


# ── Chat Session Manager ───────────────────────────────────────────────────────
def start_chat_session(model, history: list = None):
    """
    Start a new Gemini chat session with optional existing history.
    This enables multi-turn conversation memory.
    """
    formatted_history = []
    if history:
        for msg in history:
            # Convert our internal format to Gemini's expected format
            formatted_history.append({
                "role": msg["role"],
                "parts": [msg["content"]]
            })

    chat_session = model.start_chat(history=formatted_history)
    logger.info(f"Chat session started with {len(formatted_history)} prior messages.")
    return chat_session


# ── Send Message ──────────────────────────────────────────────────────────────
def send_message(chat_session, user_message: str) -> str:
    """
    Send a user message to Gemini and return the response text.
    Includes full exception handling and fallback mechanism.
    """
    if not user_message or not user_message.strip():
        return "It seems like your message was empty. Feel free to share what's on your mind."

    try:
        logger.info(f"Sending message to Gemini. Length: {len(user_message)} chars")
        response = chat_session.send_message(user_message)

        # Log token usage for optimization monitoring
        if hasattr(response, 'usage_metadata'):
            usage = response.usage_metadata
            logger.info(
                f"Token usage — Input: {usage.prompt_token_count}, "
                f"Output: {usage.candidates_token_count}, "
                f"Total: {usage.total_token_count}"
            )

        reply = response.text
        logger.info(f"Response received. Length: {len(reply)} chars")
        return reply

    except genai.types.BlockedPromptException:
        logger.warning("Message was blocked by Gemini safety filters.")
        return (
            "I wasn't able to process that message due to content guidelines. "
            "Could you rephrase, or share what's troubling you in a different way? "
            "I'm here to help."
        )

    except genai.types.StopCandidateException as e:
        logger.error(f"StopCandidateException: {e}")
        return (
            "I encountered an issue generating a response. "
            "Please try sharing your thoughts again."
        )

    except Exception as e:
        logger.error(f"Unexpected error communicating with Gemini API: {e}", exc_info=True)
        return (
            "I'm having a little trouble connecting right now. "
            "Please try again in a moment. If the issue persists, the service may be temporarily unavailable."
        )