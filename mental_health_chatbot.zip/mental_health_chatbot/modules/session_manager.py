"""
Session Memory Manager
Handles multi-turn conversation history and session state management.
"""

import logging
from datetime import datetime

logger = logging.getLogger(__name__)

MAX_HISTORY_LENGTH = 20  # Keep last 20 exchanges to manage token usage


def initialize_session_state(st):
    """
    Initialize all Streamlit session state variables.
    Called once at app startup.
    """
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []        # Full display history
        logger.info("New chat session started.")

    if "gemini_session" not in st.session_state:
        st.session_state.gemini_session = None    # Gemini chat session object

    if "model" not in st.session_state:
        st.session_state.model = None             # Gemini model instance

    if "session_start_time" not in st.session_state:
        st.session_state.session_start_time = datetime.now().strftime("%Y-%m-%d %H:%M")

    if "message_count" not in st.session_state:
        st.session_state.message_count = 0


def add_message(st, role: str, content: str):
    """
    Add a message to the session history.
    role: "user" or "assistant"
    """
    st.session_state.chat_history.append({
        "role": role,
        "content": content,
        "timestamp": datetime.now().strftime("%H:%M")
    })

    # Keep history within token limits by pruning oldest messages
    if len(st.session_state.chat_history) > MAX_HISTORY_LENGTH * 2:
        # Keep the first message (welcome context) + recent messages
        st.session_state.chat_history = (
            st.session_state.chat_history[:1] +
            st.session_state.chat_history[-(MAX_HISTORY_LENGTH * 2 - 1):]
        )
        logger.info("Chat history pruned to manage token usage.")

    if role == "user":
        st.session_state.message_count += 1


def get_history_for_gemini(st) -> list:
    """
    Format chat history for passing to Gemini API.
    Returns list of {role, content} dicts (without timestamps).
    """
    return [
        {"role": msg["role"], "content": msg["content"]}
        for msg in st.session_state.chat_history
    ]


def clear_session(st):
    """Reset the conversation — start fresh."""
    st.session_state.chat_history = []
    st.session_state.gemini_session = None
    st.session_state.message_count = 0
    st.session_state.session_start_time = datetime.now().strftime("%Y-%m-%d %H:%M")
    logger.info("Session cleared by user.")
