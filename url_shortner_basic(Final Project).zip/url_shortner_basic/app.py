from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import os
import random
import string
import validators
from models import db, URL

app = Flask(__name__)

# Database Configuration
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'database.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
Migrate(app, db)

# Home Page - shorten URL
@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        org_url = request.form.get('org_url')
        
        # Validate URL
        if not validators.url(org_url):
            return render_template('home.html', error="Invalid URL!", shortened_url=None)
        
        # Check if URL already exists
        url_obj = URL.query.filter_by(org_url=org_url).first()
        if url_obj:
            return render_template('home.html', shortened_url=url_obj.short_url)
        
        # Generate short URL code
        short_code = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
        short_url = request.host_url + short_code
        
        # Save to DB
        new_url = URL(org_url=org_url, short_url=short_url, short_code=short_code)
        db.session.add(new_url)
        db.session.commit()
        
        return render_template('home.html', shortened_url=short_url)
    
    return render_template('home.html', shortened_url=None)

# Redirect short URL
@app.route('/<short_code>')
def redirect_url(short_code):
    url_obj = URL.query.filter_by(short_code=short_code).first_or_404()
    return redirect(url_obj.org_url)

# History Page
@app.route('/history')
def history():
    urls = URL.query.all()
    return render_template('history.html', urls=urls)

if __name__ == '__main__':
    app.run(debug=True)