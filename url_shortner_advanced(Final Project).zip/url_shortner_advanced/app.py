from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db, migrate, login_manager
from models import User, URL
from config import Config
import random
import string
import validators

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
migrate.init_app(app, db)
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash("Invalid username or password")
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if len(username) < 5 or len(username) > 9:
            flash("Username must be between 5 to 9 characters long")
            return redirect(url_for('signup'))

        if User.query.filter_by(username=username).first():
            flash("This username already exists")
            return redirect(url_for('signup'))

        new_user = User(
            username=username,
            password=generate_password_hash(password)
        )
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('home'))

    return render_template('signup.html')

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    shortened_url = None

    if request.method == 'POST':
        org_url = request.form['org_url']

        if not validators.url(org_url):
            flash("Invalid URL")
            return redirect(url_for('dashboard'))

        short_code = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
        short_url = request.host_url + short_code

        new_url = URL(
            org_url=org_url,
            short_url=short_url,
            short_code=short_code,
            user_id=current_user.id
        )
        db.session.add(new_url)
        db.session.commit()
        shortened_url = short_url

    urls = URL.query.filter_by(user_id=current_user.id).all()
    return render_template('dashboard.html', urls=urls, shortened_url=shortened_url)

@app.route('/<short_code>')
def redirect_url(short_code):
    url = URL.query.filter_by(short_code=short_code).first_or_404()
    return redirect(url.org_url)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)